//
// Created by LENOVO on 2024/9/20.
//

#ifndef MACRO_H

//#define DEBUG
// #define DEBUG_PARSER
//#define DEBUG_SEMANTIC
#define IR_DEBUG
#define MIPS_DEBUG

//#define LEXER_
//#define PARSER_
//#define SEMANTIC_
//#define SYMTABLE_
#define LLVM_IR

#define MACRO_H

#endif //MACRO_H
